export const HOST = "localhost:1234";
export const SERVER_URL = `http://${HOST}`;
